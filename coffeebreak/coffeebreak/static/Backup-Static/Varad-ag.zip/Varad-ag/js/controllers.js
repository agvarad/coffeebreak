function InvoiceCntl($scope) {
  $scope.qty = 1;
  $scope.cost = 19.95;
}